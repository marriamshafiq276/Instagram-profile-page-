# Northstar Studio Profile Page

A clean Instagram-style profile page built with HTML and Tailwind CSS.

## Project Overview
This project is a front-end mockup inspired by Instagram profile layouts. It includes:
- profile header with avatar, username, bio, and stats
- post grid section with cards and overlay effects
- mobile-friendly responsive layout
- modern minimal styling

## Files
- `index.html` — main profile page structure
- `style.css` — custom styling enhancements
- `script.js` — project script file
- `images/` — project images

## Technologies Used
- HTML5
- Tailwind CSS
- Font Awesome
- CSS custom styling

## How to Run
1. Open the project folder.
2. Launch `index.html` in a browser.

You can also use a local preview server if you prefer.

## Brand
This project is branded as Northstar Studio and is designed as a professional portfolio/profile concept.

## License
This project is for educational/demo purposes.
